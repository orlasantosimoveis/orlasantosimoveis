export default function Home() {
  return (
    <div style={{fontFamily: 'Arial', padding: 40}}>
      <h1>Orla Santos Imóveis</h1>
      <p>Sistema imobiliário em funcionamento.</p>
      <p>Seu deploy está funcionando corretamente.</p>
    </div>
  );
}